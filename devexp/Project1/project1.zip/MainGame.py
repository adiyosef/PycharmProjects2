
from Live import load_game, welcome


print(welcome("adi"))
load_game()

